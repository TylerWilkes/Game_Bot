import java.util.*;

class Main {

public static void delay(int ms) {
  if (1 == 1) { //set to != if you want to skip on all purposeful delays
    try {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
    }
}
}

public static boolean ifYes(String in) {
  if (in.contains("yes") || in.contains("yep") || in.contains("yup") || in.contains("yea") || in.contains("ya") || in.contains("sure")) {
    return true;
  }
  return false;
}
public static boolean ifNo(String in) {
  if (in.contains("no") || in.contains("nope") || in.contains("not") || in.contains("na") || in.contains("nah") || in.contains("stop")) {
    return true;
  }
  return false;
}
  
  public static void main(String[] args) {

    String inputBeginning;

    //beginning conversation
    Scanner reader4 = new Scanner(System.in);

    System.out.println("\nBooting program...");
    System.out.println("Program started properly...\n");

    System.out.print("Hello!"); delay(2000);
    System.out.println(" I am your friendly game bot, Shodo."); delay(2000);

    System.out.println("\nHow are you doing today?");
    inputBeginning = reader4.nextLine();
    inputBeginning = inputBeginning.toLowerCase();

    System.out.print("\nWell, I hope I can make your day ");
    if ((inputBeginning.contains("good") || inputBeginning.contains("good")) && !ifNo(inputBeginning)) {
      System.out.print("even ");
    }
    System.out.println("better!"); delay(2000);

    NumGuessing numGuessing = new NumGuessing();
    numGuessing.runNumGuessing();

    RPS rps = new RPS();
    rps.runRPS();

    Battleship battleship = new Battleship();
    battleship.runBattleship();

    TTT ttt = new TTT();
    ttt.runTTT();

} //PSVM close
} //class close