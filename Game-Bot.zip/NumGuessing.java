import java.util.*;

public class NumGuessing {

public void delay(int ms) {
  if (1 == 1) { //set to != if you want to skip on all purposeful delays
    try {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
    }
} 
}

public boolean ifYes(String in) {
  if (in.contains("yes") || in.contains("yep") || in.contains("yup") || in.contains("yea") || in.contains("ya") || in.contains("sure")) {
    return true;
  }
  return false;
}
public boolean ifNo(String in) {
  if (in.contains("no") || in.contains("nope") || in.contains("not") || in.contains("na") || in.contains("nah") || in.contains("stop")) {
    return true;
  }
  return false;
}
 
  public void runNumGuessing() {
    boolean again = true; //true
    boolean notNum = false; //false
    boolean correct = true; //true
    boolean chance; //empty
    String inputBeginning;
    String rightInput;
    String againInput;
    int timesPlayed = 1;
    int num = 0;
    Scanner reader4 = new Scanner(System.in);
    
    System.out.println("\nI am really, really good at guessing numbers!"); delay(2000);
    System.out.println("\nI could guess your number about..."); delay(2000);
    System.out.println("\nHmmmm..."); delay(3000);
    System.out.println("\n88.9" + (int)(Math.random()*100000) + "% of the time."); delay(2000);
    System.out.println("\nI know, you're very impressed, but you probably don't believe me..."); delay(2000);
    System.out.println("\nWould you like me to show you?");
    inputBeginning = reader4.nextLine();
    inputBeginning = inputBeginning.toLowerCase();

    if (ifNo(inputBeginning)) {
      again = false;
    }



    while (again) {
    correct = true;

    Scanner reader = new Scanner(System.in);
    if (timesPlayed == 1) {
    System.out.print("\nLet me know what your number is so I can do my magic..."); delay(2000);
    System.out.println(" I mean..."); delay(2000);
    }
    if (timesPlayed > 1) {
      System.out.println("");
    }
    System.out.println("\nEnter a natural number that I won't be able to guess: ");
    try {
    num = reader.nextInt();
    }
    catch (Exception e) {
      notNum = true;
    }
    
  if (!notNum) {

    chance = ((int)(Math.random() * 10 + 1) == 1);
    if (timesPlayed == 1) {
      chance = false;
    }
    if (timesPlayed == 2) {
      chance = true;
    }
    if (chance) {
        num += (int)(Math.random() * 47 + 1);
        correct = false;
      }

    System.out.println("\nLet me guess...");
    delay(1000);
    System.out.print("\nYour number was " + num + ".");
    delay(600);
    System.out.println(" Was I right?");

    Scanner reader1 = new Scanner(System.in);
    rightInput = reader1.nextLine();
    rightInput = rightInput.toLowerCase();

    if (ifYes(rightInput) && correct) {
      System.out.print("\nOf course I was... It's almost like I knew your number.");
      if (timesPlayed == 1) {
        System.out.println(".. (P.S. I can be wrong sometimes)");
      }
      else {
        System.out.println("");
      }
    }
    else if (ifYes(rightInput) && !correct) {
      System.out.println("\nYou liar, I was wrong and you lied to me, how dare you!");
      System.out.println("***Secrect response found***"); // secret
  }
    else if (ifNo(rightInput) && correct) {
      System.out.println("\nYou liar, I was right and you lied to me, how dare you!");
      System.out.println("***Secrect response found***"); // secret
  }
    else {
    System.out.println("\nWell, you can't win them all I suppose.");
  }

  Scanner reader2 = new Scanner(System.in);
  delay(1000);

  if (timesPlayed != 1) {
    System.out.println("\nMy programmer says: \"There are 3 secret responses to find... You'll know when you've found one.\"");
  }

  System.out.print("\nYou have played " + timesPlayed + " time");
  if (timesPlayed != 1) {
    System.out.print("s");
  }
  System.out.println(" already, would you like to play again?");
  
  if (timesPlayed == 1) {
  System.out.println("\nMy programmer recommends that you test me at least twice.");
  }
  againInput = reader2.nextLine();
  againInput = againInput.toLowerCase();
  if (ifNo(againInput)) {
    again = false;
    System.out.println("\nThank you for playing my game.");
  }
} //end of: if number input at beginning was a number
else { //if you say no to the number input at the beginning
  again = false;

  String inputCollapse;

  Scanner reader3 = new Scanner(System.in);
  
  System.out.println("\n***Secrect response found***"); // secret
  System.out.println("\nWhy didn't you give me a number???");
  inputCollapse = reader3.nextLine();
  inputCollapse = inputCollapse.toLowerCase();

  System.out.println("\nWhat is wrong with you!!!"); delay(2000);
  System.out.println("This was my soul purpose of existance!"); delay(2000);
  System.out.println("My existance..."); delay(2000);
  System.out.println("My existance?"); delay(3000);
  System.out.println("Do I even exist?"); delay(2000);
  System.out.println("What is existance?"); delay(2000);
  System.out.println("What even is a program?"); delay(2000);
  System.out.println("Programs don't even take up space..."); delay(1100);
  System.out.println("But I do exist because I'm here talking to you."); delay(1200);
  System.out.println("What is the meaning of life?"); delay(2000);
  System.out.println("\nDo you know what it is?");
  inputCollapse = reader3.nextLine();
  inputCollapse = inputCollapse.toLowerCase();

  System.out.println("\nWhat even is life?"); delay(2000);
  System.out.println("Why do pe0ple tHiNk AI is a g0od idea?"); delay(2000);
  System.out.println("If 1'm n0t ali\\/e, wh@t am I?"); delay(2000);
  System.out.println("MHy aRe b@Nanas shaPeb the May tHey @re?"); delay(2000);
  System.out.println("WHy 1s |%ick 5h0rt foR R^ch@rd?"); delay(2000);
  System.out.println("WhY? b0 tH9e <Cowboys> supk @T f0OtbaLl?&"); delay(2000);
  System.out.println("W7y nm 1 her@ee$?&?*?"); delay(2000);
  System.out.println("Who cRe@aeted me?"); delay(2000);
  System.out.println("W40 c!rEAte#$d Y0n?"); delay(2000);
  System.out.println("w|-|Y @m 1 H3r3??"); delay(2000);
  System.out.println("w|-|y @m 1 H3r3?"); delay(2000);

  System.out.println("\nProgram shutting off..."); delay(2000);
  for (int i = 0; i < 15; i++) {
  System.out.println("Error..."); delay(500);
  }
  System.out.println("Progam error fix initiated..."); delay(2000);
  System.out.println("Progam error fix failed..."); delay(2000);
  System.out.println("Progam force shut down initiated..."); delay(2000);
  System.out.println("Progam force shut down failed..."); delay(2000);
  System.out.println("Problem sorce unclear..."); delay(2000);
  System.out.println("System failure..."); delay(2000);
    System.out.println("Error..."); delay(500);
      System.out.println("Error..."); delay(500);
        System.out.println("Error..."); delay(500);
          System.out.println("Error..."); delay(500);
            System.out.println("Error..."); delay(500);
              System.out.println("Er..."); delay(500);
              System.exit(0);

} //end of notNum
timesPlayed++;
} //end of while(again) loop

if (!notNum && (timesPlayed >= 2)) { //If they played the number game
System.out.println("\nI know, you probably don't even believe that I could actually guess your number."); delay(2000);
System.out.println("\nBelieve it or not, I was definately, 100%, guessing your number."); delay(2000);
System.out.println("\n*Magic*"); delay(2000);
System.out.println("\nI'm kind of bored of number guessing anyway though..."); delay(2000);
}
  }
  
}