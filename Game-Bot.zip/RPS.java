import java.util.*;

public class RPS {

public void delay(int ms) {
  if (1 == 1) { //set to != if you want to skip on all purposeful delays
    try {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
    }
} 
}

public boolean ifYes(String in) {
  if (in.contains("yes") || in.contains("yep") || in.contains("yup") || in.contains("yea") || in.contains("ya") || in.contains("sure")) {
    return true;
  }
  return false;
}
public boolean ifNo(String in) {
  if (in.contains("no") || in.contains("nope") || in.contains("not") || in.contains("na") || in.contains("nah") || in.contains("stop")) {
    return true;
  }
  return false;
}
 
  public void runRPS() {
    
    boolean again = true; //true
    boolean correct = true; //true
    boolean chance; //empty
    String inputBeginning;
    String rightInput;
    String againInput;
    int timesPlayed = 1;
    int num = 0; //number input at the beginning
    String cpuThrow;
  String playerThrow;
  int winsRPS = 0;
  int cpuWinsRPS = 0;
    Scanner reader4 = new Scanner(System.in);
    
    if (again) { //RPS section open
  Scanner reader5 = new Scanner(System.in);
  String inputRPSM;

  if (!(timesPlayed >= 2)) {
    System.out.println("");
  }

  System.out.println("I have another game you might like."); delay(2000);
  System.out.println("\nIt's called Rock Paper Scissors."); delay(2000);
  System.out.println("\nHave you played before?");
  inputRPSM = reader5.nextLine();
  inputRPSM = inputRPSM.toLowerCase();

  if (ifNo(inputRPSM)) {

    System.out.println("\nIn this game you can choose to \"throw\" a rock (fist), paper (flat hand), or scissors (index and middle finger extended)."); delay(3000);
    System.out.println("\nThe other player will do the same thing at random."); delay(2000);
    System.out.println("\nRock beats scissors, scissors beats paper, and paper beats rock."); delay(2000);
    System.out.println("\nIf you beat the other player then you win that round."); delay(2000);
  }
  System.out.println("\nWould you like to play it with me?");
  inputRPSM = reader5.nextLine();
  inputRPSM = inputRPSM.toLowerCase();
  


  boolean againRPS = true;
  int timesPlayedRPS = 0;
  boolean tie = false;

  if (!ifNo(inputRPSM)) { //start RPS
  while(tie || againRPS) { //loop RPS

  timesPlayedRPS++;

  if (tie) {
    System.out.println("Tie! Throw again.");
  }

  tie = false;
  if (timesPlayedRPS == 1) {
  System.out.println("\nJust for you I'll tell you when I've computed my throw.");
  }
  System.out.println("\nRock"); delay(1000);
  System.out.println("Paper"); delay(1000);
  System.out.println("Scissors"); delay(1000);
  System.out.println("Shoot\n"); delay(1000);

  int throwNum = (int) (Math.random()*3 + 1);

  if (throwNum == 1) {
    cpuThrow = "rock";
  }
  else if(throwNum == 2) {
    cpuThrow = "paper";
  }
  else {
    cpuThrow = "scissors";
  }
  System.out.println("I have computed my throw.\n"); delay(1000);

    System.out.println("What did you throw?");
    playerThrow = reader5.nextLine();
    playerThrow = playerThrow.toLowerCase();

    while(!(playerThrow.equals("rock") || playerThrow.equals("paper") || playerThrow.equals("scissors"))) {
      System.out.print("Incorrect input, ");
      System.out.println("What did you throw?");
    playerThrow = reader5.nextLine();
    playerThrow = playerThrow.toLowerCase();
    }

    System.out.println("I threw " + cpuThrow + ".\n"); delay(2000);

    if(cpuThrow.contains("rock") && playerThrow.contains("paper")) {
      System.out.print("You won, congrats!");
      winsRPS++;
    }
    else if(cpuThrow.contains("rock") && playerThrow.contains("scissors")) {
      System.out.print("I won, ");
      if (cpuWinsRPS >= 1) {
        System.out.print("again,");
      }
      System.out.print("loser.");
      cpuWinsRPS++;
    }
    else if(cpuThrow.contains("paper") && playerThrow.contains("rock")) {
      System.out.print("I won, ");
      if (cpuWinsRPS >= 1) {
        System.out.print("again,");
      }
      System.out.print("loser.");
      cpuWinsRPS++;
    }
    else if(cpuThrow.contains("paper") && playerThrow.contains("scissors")) {
      System.out.print("You won, congrats!");
      winsRPS++;
    }
    else if(cpuThrow.contains("scissors") && playerThrow.contains("rock")) {
      System.out.print("You won, congrats!");
      winsRPS++;
    }
    else if(cpuThrow.contains("scissors") && playerThrow.contains("paper")) {
      System.out.print("I won, ");
      if (cpuWinsRPS >= 1) {
        System.out.print("again,");
      }
      System.out.print("loser.");
      cpuWinsRPS++;
    }
    else{
      tie = true;
    }
    if (!tie) {
      System.out.print(" You have played " + timesPlayedRPS + " time");
      if (timesPlayedRPS != 1) {
        System.out.print("s");
      }
      System.out.print(" and won " + winsRPS + " time");
      if (winsRPS != 1) {
        System.out.print("s");
      }
      System.out.println(".");
      System.out.println("\nWould you like to play again?");
        String inputRPS;
        inputRPS = reader5.nextLine();
        inputRPS = inputRPS.toLowerCase();
        if (ifNo(inputRPS)) {
          System.out.println("\nThank you for playing that with me!\n");
          againRPS = false;
        }
    }
  }
  }// RPS close

else { //if they didn't want to play RPS
  System.out.println();
} //if they didn't want to play RPS close
} // RPS section close

  }

}