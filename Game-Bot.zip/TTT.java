import java.util.*;
  
public class TTT {

  static int playerWins = 0;
  static int timesPlayed = 0;

  public static void delay(int ms) {
  if (1 == 1) { //set to != if you want to skip on all purposeful delays
    try {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
    }
} 
}

public static boolean ifYes(String in) {
  if (in.contains("yes") || in.contains("yep") || in.contains("yup") || in.contains("yea") || in.contains("ya") || in.contains("sure")) {
    return true;
  }
  return false;
}
public static boolean ifNo(String in) {
  if (in.contains("no") || in.contains("nope") || in.contains("not") || in.contains("na") || in.contains("nah") || in.contains("stop")) {
    return true;
  }
  return false;
}
    
    static String[] board;
    static String turn;
    
    
    // CheckWinner method will 
    // decide the combination 
    // of three box given below.

    public boolean isNumeric(String string) {
    int intValue;
		
    if(string == null || string.equals("")) {
        return false;
    }
    
    try {
        intValue = Integer.parseInt(string);
        return true;
    }
    catch (NumberFormatException e) {

    }
    return false;
}

    public String checkWinner()
    {
        for (int a = 0; a < 8; a++) {
            String line = null;
  
            switch (a) {
            case 0:
                line = board[0] + board[1] + board[2];
                break;
            case 1:
                line = board[3] + board[4] + board[5];
                break;
            case 2:
                line = board[6] + board[7] + board[8];
                break;
            case 3:
                line = board[0] + board[3] + board[6];
                break;
            case 4:
                line = board[1] + board[4] + board[7];
                break;
            case 5:
                line = board[2] + board[5] + board[8];
                break;
            case 6:
                line = board[0] + board[4] + board[8];
                break;
            case 7:
                line = board[2] + board[4] + board[6];
                break;
            }
            //For X winner
            if (line.equals("XXX")) {
                return "cpu";
            }
              
            // For O winner
            else if (line.equals("OOO")) {
                return "player";
            }
        }
          
        for (int a = 0; a < 9; a++) {
            if (Arrays.asList(board).contains(String.valueOf(a + 1))) {
                break;
            }
            else if (a == 8) {
                return "draw";
            }
        }
  
        return null;
    }

    public int checkForWinningMove() {
      int numSpot = -1;
      int lineNum = -1;
      String line = null;

        for (int a = 0; a < 8; a++) {
            line = null;
  
            switch (a) {
            case 0:
                line = board[0] + board[1] + board[2];
                break;
            case 1:
                line = board[3] + board[4] + board[5];
                break;
            case 2:
                line = board[6] + board[7] + board[8];
                break;
            case 3:
                line = board[0] + board[3] + board[6];
                break;
            case 4:
                line = board[1] + board[4] + board[7];
                break;
            case 5:
                line = board[2] + board[5] + board[8];
                break;
            case 6:
                line = board[0] + board[4] + board[8];
                break;
            case 7:
                line = board[2] + board[4] + board[6];
                break;
            }
            //For X winner
            if ((line.charAt(0) == 'X' && line.charAt(1) != 'O' && line.charAt(2) == 'X') || (line.charAt(0) == 'X' && line.charAt(2) != 'O' && line.charAt(1) == 'X') || (line.charAt(1) == 'X' && line.charAt(0) != 'O' && line.charAt(2) == 'X')) {
              lineNum = a;
              a = 999;
            }
        }

      if (lineNum >= 0) {
        switch (lineNum) {
          case 0:
            if (line.charAt(0) == 'X') {
              numSpot = 2;
            }
            else {
              numSpot = 0;
            }
          break;
          case 1:
            if (line.charAt(0) == 'X') {
              numSpot = 5;
            }
            else {
              numSpot = 3;
            }
          break;
          case 2:
            if (line.charAt(0) == 'X') {
              numSpot = 8;
            }
            else {
              numSpot = 6;
            }
          break;
          case 3:
            if (line.charAt(0) == 'X') {
              numSpot = 6;
            }
            else {
              numSpot = 0;
            }
          break;
          case 4:
            if (line.charAt(0) == 'X') {
              numSpot = 7;
            }
            else {
              numSpot = 1;
            }
          break;
          case 5:
            if (line.charAt(0) == 'X') {
              numSpot = 8;
            }
            else {
              numSpot = 2;
            }
          break;
          case 6:
            if (line.charAt(0) == 'X') {
              numSpot = 8;
            }
            else {
              numSpot = 0;
            }
          break;
          case 7:
            if (line.charAt(0) == 'X') {
              numSpot = 6;
            }
            else {
              numSpot = 2;
            }
          break;
          default:
            numSpot = -1;
          break;
        }
      }
  
        return numSpot;
    }
    

    public int checkForPlayerWinningMove() {
      int numSpot = -1;
      int lineNum = -1;
      String line = null;

        for (int a = 0; a < 8; a++) {
            line = null;
  
            switch (a) {
            case 0:
                line = board[0] + board[1] + board[2];
                break;
            case 1:
                line = board[3] + board[4] + board[5];
                break;
            case 2:
                line = board[6] + board[7] + board[8];
                break;
            case 3:
                line = board[0] + board[3] + board[6];
                break;
            case 4:
                line = board[1] + board[4] + board[7];
                break;
            case 5:
                line = board[2] + board[5] + board[8];
                break;
            case 6:
                line = board[0] + board[4] + board[8];
                break;
            case 7:
                line = board[2] + board[4] + board[6];
                break;
            }
            //For X winner
            if ((line.charAt(0) == 'O' && line.charAt(1) != 'X' && line.charAt(2) == 'O') || (line.charAt(0) == 'O' && line.charAt(2) != 'X' && line.charAt(1) == 'O') || (line.charAt(1) == 'O' && line.charAt(0) != 'X' && line.charAt(2) == 'O')) {
              lineNum = a;
              a = 999;
            }
        }

      if (lineNum >= 0) {
        switch (lineNum) {
          case 0:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 0;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 1;
            }
            else {
              numSpot = 2;
            }
          break;
          case 1:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 3;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 4;
            }
            else {
              numSpot = 5;
            }
          break;
          case 2:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 6;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 7;
            }
            else {
              numSpot = 8;
            }
          break;
          case 3:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 0;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 3;
            }
            else {
              numSpot = 6;
            }
          break;
          case 4:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 1;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 4;
            }
            else {
              numSpot = 7;
            }
          break;
          case 5:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 2;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 5;
            }
            else {
              numSpot = 8;
            }
          break;
          case 6:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 0;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 4;
            }
            else {
              numSpot = 8;
            }
          break;
          case 7:
            if (line.charAt(1) == 'O' && line.charAt(2) == 'O') {
              numSpot = 2;
            }
            else if(line.charAt(0) == 'O' && line.charAt(2) == 'O') {
              numSpot = 4;
            }
            else {
              numSpot = 6;
            }
          break;
          default:
            numSpot = -1;
          break;
        }
      }
  
        return numSpot;
    }

    public void printBoard()
    {
        System.out.println("\n    |   |");
        System.out.println("  " + board[0] + " | " + board[1] + " | " + board[2]);
        System.out.println("-------------");
        System.out.println("  " + board[3] + " | " + board[4] + " | " + board[5]);
        System.out.println("-------------");
        System.out.println("  " + board[6] + " | " + board[7] + " | " + board[8]);
        System.out.println("    |   |");
        delay(2000);
    }
  
    public void runTTT() {
        Scanner reader = new Scanner(System.in);
        String r = "";
        boolean again = false;
  




  
        System.out.println("\nHere's a childhood favorite for most people:"); delay(3000);
        System.out.println("\nIt's called \"Tic Tac Toe\"."); delay(3000);
        System.out.println("\nDo you know how to play?");
        r = reader.nextLine();
        if (ifNo(r)) {
          System.out.println("\nIt's a super easy game."); delay(2000);
          System.out.println("\nWe will take turns playing on a 3x3 grid that looks like this:\n"); delay(3000);
          printBoard();
          delay(2000);
          System.out.println("We will take turns placing \"X\"\'s and \"O\"\'s."); delay(4000);
          System.out.println("\nIf someone makes 3 in a row, they win."); delay(3000);
        }
        System.out.println("\nWould you like to play Tic Tac Toe with me?");
        r = reader.nextLine();
        if (!ifNo(r)) {
          again = true;
          System.out.println("\nCool!\n"); delay(1000);
        }

        

        while(again) {

        board = new String[9];
        String winner = null;
        int lastTurn = 0;
        int cpuTurn = 1;
        int cpuPlay = 0;
        for (int a = 0; a < 9; a++) {
          board[a] = String.valueOf(a + 1);
        }




        System.out.println("I will play first.");

        board[4] = "X";
        printBoard();
  
        while (winner == null ) {
          cpuTurn++;
          String in = "";

            System.out.println("\nEnter the location of your move:");
            in = reader.nextLine();

            while ((!(in.length() == 1 && isNumeric(in)) || !(Integer.valueOf(in) >= 1 && Integer.valueOf(in) <= 9)) || !(isNumeric(board[Integer.valueOf(in) - 1]))) {
              System.out.println("\nInvalid input, try again:");
              in = reader.nextLine();
            }

            lastTurn = Integer.valueOf(in) - 1;
            board[lastTurn] = "O";
            printBoard();
            
            winner = checkWinner();

            //Comupter's turn \/

            if (winner == null) {

              System.out.println("\nI'll move here:"); delay(2000);

              
              if (checkForWinningMove() >= 0 || checkForPlayerWinningMove() >= 0) {
                if (checkForWinningMove() >= 0) {
                  board[checkForWinningMove()] = "X";
                }
                else if (checkForPlayerWinningMove() >= 0) {
                  board[checkForPlayerWinningMove()] = "X";
                }
              }
              else {
                cpuPlay = (int)(Math.random()*9);
                while (board[cpuPlay].charAt(0) == 'O' || board[cpuPlay].charAt(0) == 'X') {
                  cpuPlay = (int)(Math.random()*9);
                }
                board[cpuPlay] = "X";
              }

              printBoard();
              winner = checkWinner();

            }//if(winner == null)

        }//while no winner

        if (winner.equalsIgnoreCase("draw")) {
            System.out.println("\nIt's a draw! Thanks for playing.");
        }
        
        // For winner -to display Congratulations! message.
        else {
            if (winner.equals("player")) {
              System.out.println("\nGood job, you beat me in Tic Tac Toe!"); delay(3000);
              playerWins++;
            }
            else {
              System.out.println("\nYou lost, sucks to suck. I'd love to play you again though ;)"); delay(3000);
            }
        }

    timesPlayed++;
    System.out.println("\nYou have played " + timesPlayed + " times and won " + playerWins + " times."); delay(3000);
    if (playerWins == 0 && timesPlayed == 1) {
    System.out.println("\nI guess I'm pretty good at this game."); delay(2000);
    }
    System.out.println("\nWould you like to play again?");
    r = reader.nextLine();

    if (ifNo(r)) {
      again = false;
    }
    else {
      System.out.println();
    }

    }//while again

      System.out.println("\nThat's unfortunate, I really enjoy that game."); delay(3000);
      System.out.println("\nThat's all I can do for now, I hope to see you again!");

    }
}

/* first move stratagizing potential:

if(cpuTurn == 2) {
  switch(lastTurn) {
    case 0:
      board[8] = "X";
    break;
    case 1:
      board[3] = "X";
    break;
    case 2:
      board[6] = "X";
    break;
    case 3:
      board[7] = "X";
    break;
    case 5:
      board[1] = "X";
    break;
    case 6:
      board[2] = "X";
    break;
    case 7:
      board[5] = "X";
    break;
    case 8:
      board[0] = "X";
    break;
  }
}
*/